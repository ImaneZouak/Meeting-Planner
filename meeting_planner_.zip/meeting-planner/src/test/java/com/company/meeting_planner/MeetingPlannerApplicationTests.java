package com.company.meeting_planner;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MeetingPlannerApplicationTests {

	@Test
	void contextLoads() {
	}

}
